
import java.util.Random;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author MohamadFadhil
 */
public class Bill extends Order {
    
    public Bill(){
    }
    
    public void displayBill(){
        //print getOrdered
        normalize();
        normalizeOrder();
        int num=1;
        double total=0;
        int param =1; //calculating the bill for table 1
        
        for (int i=0;i<orderFoodName[param].length;i++){
            
            if(orderFoodName[param][i]!=null){
                for(int j=0;j<line_no;j++){
                    if(name[j].equalsIgnoreCase(orderFoodName[param][i])){
                        total+=price[j]*orderQuantity[param][i];
                        System.out.printf("%d %-20s %-20d %-20.2f %-20.2f\n",num,orderFoodName[param][i],orderQuantity[param][i],price[j],price[j]*orderQuantity[param][i]);
                        num++;
                    }
                }
            }else{
            }
        }
        
        System.out.printf("The total price is RM%.2f\n",calcBill());
        System.out.println("This order is served by: "+assignEmployee());
        
        
    }
    
    public double calcBill(){
        //compute total price
        //add gst
        normalize();
        normalizeOrder();
        double total=0;
        int param =1; //calculating the bill for table 1
        
        for (int i=0;i<orderFoodName[param].length;i++){
            if(orderFoodName[param][i]!=null){
                //System.out.println(orderFoodName[param][i]);
                //System.out.println(orderQuantity[param][i]);
                
                for(int j=0;j<line_no;j++){
                    if(name[j].equalsIgnoreCase(orderFoodName[param][i])){
                        //System.out.println(price[j]);
                        total+=price[j]*orderQuantity[param][i];
                    }
                }
                
            }else{
            }
        }
        //System.out.println(total);
        //System.out.println("");
        //System.out.println("After taxes:");
        total+=(total*6/100+total*5/100);
        //System.out.println(total);
        
        return total;
    }
    
    public double pay(double a){
        double balance=0;
        double paid=a;
        
        balance=paid-calcBill();
        return balance;
    }
    
    public String assignEmployee(){
        //randomize a code 0 to 10. which will then be the waiters' code
        int temp;
        Random g = new Random();
        //temp = g.nextInt(10);
        temp = 2;
        int workercode = 2;
        
            for(int i=0;i<1;i++){
            if(workercode==temp){
                //get the worker.name[1];
            }
            }
            
            return "fahmi";
        }
        
    
    
    
}